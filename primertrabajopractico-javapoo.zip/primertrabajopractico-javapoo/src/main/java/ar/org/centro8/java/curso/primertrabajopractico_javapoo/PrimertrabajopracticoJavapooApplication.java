package ar.org.centro8.java.curso.primertrabajopractico_javapoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimertrabajopracticoJavapooApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimertrabajopracticoJavapooApplication.class, args);
	}

}

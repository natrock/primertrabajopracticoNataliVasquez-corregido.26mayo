package ar.org.centro8.java.curso.primertrabajopractico_javapoo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimertrabajopracticoJavapooApplicationTests {

	@Test
	void contextLoads() {
	}

}
